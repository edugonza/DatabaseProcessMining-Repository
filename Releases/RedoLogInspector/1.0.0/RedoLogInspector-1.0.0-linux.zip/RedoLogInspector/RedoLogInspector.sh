#!/bin/bash

PATH_TO_SCRIPT=`dirname $0`

JAVA=java

(
  cd $PATH_TO_SCRIPT
  $JAVA -jar RedoLogInspector-1.0.0.jar
)
